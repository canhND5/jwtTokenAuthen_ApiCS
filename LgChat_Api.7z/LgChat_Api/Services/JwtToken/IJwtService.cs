using LG_CHAT_API.Models.Auth;
using LG_CHAT_API.Models.User;

namespace LG_CHAT_API.Services.JwtToken;

public interface IJwtService
{
    Task<AuthResult> GenerateToken(UserModel user);
}
