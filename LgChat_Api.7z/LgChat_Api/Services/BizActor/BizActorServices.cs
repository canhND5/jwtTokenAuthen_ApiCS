﻿using LG_CHAT_API.Models.BizActor;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace LG_CHAT_API.Services.BizActor
{
    public class BizActorServices
    {
        private readonly string? baseUri;
        private readonly IConfiguration _configuration;
        public BizActorServices(IConfiguration configuration)
        {
            _configuration = configuration;
            baseUri = _configuration["BizActorUrl"];
        }

        public async Task<BizActorResponse> Call(BizActorRequest request)
        {
            var result = new BizActorResponse();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUri!);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.PostAsJsonAsync("bizarest", request);
                if (response.IsSuccessStatusCode)
                {
                    var customerJsonString = await response.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<BizActorResponse>(customerJsonString);

                    //var jsonObject = JObject.Parse(customerJsonString);
                    //var Status = (string)jsonObject["status"];
                }
            }

            return result;
        }

        public List<T> GetOutdata<T>(BizActorResponse bizActorResponse, string tableName)
        {
            // demo cast dictionary to object
            string listStr = JsonConvert.SerializeObject(bizActorResponse.Result![tableName]);
            var data = JsonConvert.DeserializeObject<List<T>>(listStr);

            return data;
        }
    }
}
