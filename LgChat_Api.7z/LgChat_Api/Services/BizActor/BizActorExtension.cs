﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Reflection;
using System.Text.Json;

namespace LG_CHAT_API.Services.BizActor
{
    public static class BizActorExtension
    {
        public static Dictionary<string, List<object>> AddInputData<T>(this Dictionary<string, List<object>> inputData, string tableName, List<T> addData)
        {
            // Use reflection to get the properties of the Person class
            PropertyInfo[] properties = typeof(T).GetProperties();

            var listObj = new List<object>();
            foreach (var data in addData)
            {
                // Loop through the properties and print their values
                var jObject = new JObject();

                foreach (PropertyInfo property in properties)
                {
                    // Get the value of the property
                    if (property.GetValue(data) is not null)
                    {
                        string? value = property.GetValue(data)!.ToString();
                        jObject[property.Name] = value;
                    }
                }
                var str = JsonConvert.SerializeObject(jObject);
                var obj = JsonDocument.Parse(str).RootElement;
                listObj.Add(obj);
            }

            inputData.Add(tableName, listObj);

            return inputData;
        }

    }
}
