﻿using LG_CHAT_API.Models.Auth.Request;
using LG_CHAT_API.Models.BizActor;
using LG_CHAT_API.Models.User;

namespace LG_CHAT_API.Services.User
{
    public interface IUserService
    {
        public Task<UserModel> GetUserByEmail(string email);
        Task<BizActorResponse> AddUser(object user);
        Task<BizActorResponse> Update(object user);
        Task<BizActorResponse> DisableUser(int userId);
        Task<bool> CheckLogin(LoginUserDTO user);
    }
}
