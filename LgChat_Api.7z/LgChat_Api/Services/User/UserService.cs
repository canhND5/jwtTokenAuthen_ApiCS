﻿using LG_CHAT_API.Models.Auth.Request;
using LG_CHAT_API.Models.BizActor;
using LG_CHAT_API.Models.User;
using LG_CHAT_API.Services.BizActor;

namespace LG_CHAT_API.Services.User
{
    public class UserService : IUserService
    {
        private readonly BizActorServices _bizactorServices;
        public UserService(BizActorServices bizactorServices)
        {
            _bizactorServices = bizactorServices;
        }

        public Task<BizActorResponse> AddUser(object user)
        {
            throw new NotImplementedException();
        }

        public Task<bool> CheckLogin(LoginUserDTO user)
        {
            throw new NotImplementedException();
        }

        public Task<BizActorResponse> DisableUser(int userId)
        {
            throw new NotImplementedException();
        }

        public Task<BizActorResponse> Update(object user)
        {
            throw new NotImplementedException();
        }

        async Task<UserModel> IUserService.GetUserByEmail(string email)
        {
            //var request = BizActorServices.CreateBizActorRequest("actId", "inDtName", "outDt", email);
            //var response = await _bizactorServices.Call(request);


            return new UserModel();
        }
    }
}
