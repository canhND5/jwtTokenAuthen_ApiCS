using LG_CHAT_API.Config;
using LG_CHAT_API.Config.Middlewares;
using LG_CHAT_API.Services.BizActor;
using LG_CHAT_API.Services.JwtToken;
using LG_CHAT_API.Services.User;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// add signalR
builder.Services.AddSignalR(o =>
{
    o.EnableDetailedErrors = true;
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Validation params
TokenValidationParameters? tokenValidationParams = new TokenValidationParameters
{
    ValidateIssuer = true,
    ValidateAudience = true,
    ValidIssuer = "your_issuer",
    ValidAudience = "your_audience",
    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("your_secret_key_your_secret_key")),
    RequireExpirationTime = true,
    // ClockSkew = TimeSpan.Zero,
};

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddJwtBearer(options =>
        {
            options.RequireHttpsMetadata = false;
            options.SaveToken = true;
            options.TokenValidationParameters = tokenValidationParams;
        });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminRole", policy =>
        policy.RequireRole("Admin"));
});

builder.Services.AddSingleton(tokenValidationParams);

builder.Services.AddScoped<IJwtService, JwtService>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<BizActorServices>();
builder.Services.AddSingleton<CallerInfo>();

// build app
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapHub<ChatHub>("/chathub");
app.UseAuthentication();
app.UseAuthorization();

app.UseMiddleware<CallerInfoMiddleware>();

app.MapControllers();

app.Run();
