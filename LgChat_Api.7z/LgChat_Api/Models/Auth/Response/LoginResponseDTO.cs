namespace LG_CHAT_API.Models.Auth.Response;

public class LoginResponseDTO : AuthResult
{

}
