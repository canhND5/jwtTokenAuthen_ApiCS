namespace LG_CHAT_API.Models.Auth.Response;

public class RefreshTokenResponseDTO
{
    public int? UserId { get; set; }
    public bool Success { get; set; }
    public List<string>? Errors { get; set; }
}
