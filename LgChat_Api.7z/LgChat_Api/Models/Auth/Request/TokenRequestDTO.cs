using System.ComponentModel.DataAnnotations;

namespace LG_CHAT_API.Models.Auth.Request;

public class TokenRequestDTO
{
    [Required]
    public string? Token { get; set; }
    [Required]
    public string? RefreshToken { get; set; }

}
