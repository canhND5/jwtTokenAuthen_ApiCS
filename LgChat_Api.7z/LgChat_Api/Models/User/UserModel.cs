﻿namespace LG_CHAT_API.Models.User
{
    public class UserModel
    {
        public int Id { get; set; }
        public string Email { get; set; } = string.Empty;
        public string? Username { get; set; }
        public string? PhoneNumber { get; set; }
    }
}
