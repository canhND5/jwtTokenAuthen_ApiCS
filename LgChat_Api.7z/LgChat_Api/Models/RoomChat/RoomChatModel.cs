﻿namespace LG_CHAT_API.Models.RoomChat
{
    public class RoomChatModel // : ModelBase
    {
        public int? ID { get; set; }
        public string? type { get; set; }
        public bool? IS_DELETED { get; set; }
        public int? MEMBER_COUNT { get; set; }
        public int? USER_ID { get; set; }
        public string? NAME { get; set; }
    }
}
