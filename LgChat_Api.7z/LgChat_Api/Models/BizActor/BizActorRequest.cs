﻿namespace LG_CHAT_API.Models.BizActor
{
    public class BizActorRequest
    {
        public string ActID { get; set; } = string.Empty;
        public string InDTName { get; set; } = string.Empty;
        public string OutDTName { get; set; } = string.Empty;
        public object? RefDS { get; set; }
    }
}
