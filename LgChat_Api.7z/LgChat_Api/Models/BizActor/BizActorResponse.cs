﻿namespace LG_CHAT_API.Models.BizActor
{
    public class BizActorResponse
    {
        public string? Status { get; set; }
        public string? Description { get; set; }
        public Dictionary<string, List<Dictionary<string, object>>>? Result { get; set; } // {"tb1":[],"tb2":[]}
    }

}
