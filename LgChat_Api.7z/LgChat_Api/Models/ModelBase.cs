﻿namespace LG_CHAT_API.Models
{
    public class ModelBase
    {
        public int? ID { get; set; }
        public bool IS_DELETED { get; set; }
        public DateTime? CREATED_DATE { get; set; }
        public int CREATED_BY { get; set; }
        public DateTime? MODIFIED_DATE { get; set; }
        public int? MODIFIED_BY { get; set; }
    }
}
