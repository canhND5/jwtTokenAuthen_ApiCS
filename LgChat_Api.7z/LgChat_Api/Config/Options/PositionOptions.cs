﻿namespace LG_CHAT_API.Config.Options
{
    public class PositionOptions
    {
        public string Position = "Position";

        public string Title { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}
