﻿namespace LG_CHAT_API.Config.Middlewares
{
    public class CallerInfoMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<CallerInfoMiddleware> _logger;
        private readonly CallerInfo _callerInfo;

        public CallerInfoMiddleware(RequestDelegate next, ILogger<CallerInfoMiddleware> logger, CallerInfo callerInfo)
        {
            _next = next;
            _logger = logger;
            _callerInfo = callerInfo;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Lưu thông tin của người gọi
            // LogCallerInfo(context);
            _callerInfo.ID = 333;

            // Tiếp tục xử lý request
            await _next(context);
        }

    }
}
