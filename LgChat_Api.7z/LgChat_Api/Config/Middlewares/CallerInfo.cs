﻿namespace LG_CHAT_API.Config.Middlewares
{
    public class CallerInfo
    {
        public int ID { get; set; }
    }
}
