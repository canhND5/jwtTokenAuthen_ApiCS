﻿namespace LG_CHAT_API.Config
{
    public class Cl123ass
    {
    }
}
