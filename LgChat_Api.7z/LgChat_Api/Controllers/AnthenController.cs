﻿using LG_CHAT_API.Models.Auth;
using LG_CHAT_API.Models.Auth.Request;
using LG_CHAT_API.Models.Auth.Response;
using LG_CHAT_API.Models.User;
using LG_CHAT_API.Services.JwtToken;
using LG_CHAT_API.Services.User;
using Microsoft.AspNetCore.Mvc;

namespace LG_CHAT_API.Controllers
{
    public class AnthenController : ControllerBaseCustom
    {
        // Identity package
        private readonly IUserService _userService;
        private readonly IJwtService _jwtService;

        public AnthenController(IUserService userService, IJwtService jwtService)
        {
            _userService = userService;
            _jwtService = jwtService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterUserDTO user)
        {
            var ak = HttpContext.User.IsInRole("xxxx");
            if (ModelState.IsValid)
            {
                var existingUser = await _userService.GetUserByEmail(user.Email);

                if (existingUser != null)
                {
                    return BadRequest(new RegisterResponseDTO()
                    {
                        Errors = new List<string>() { "Email already Registered" },
                        Success = false
                    });
                }

                UserModel newUser = new UserModel()
                {
                    Email = user.Email,
                    Username = user.Username,
                };

                var created = await _userService.AddUser(user);
                if (created.Status == "SUCCESS")
                {
                    AuthResult authResult = await _jwtService.GenerateToken(newUser);
                    //return a token
                    return Ok(authResult);
                }
                else
                {
                    return BadRequest(new RegisterResponseDTO()
                    {
                        Errors = new List<string>() { created.Description },
                        Success = false
                    });
                }
            }

            return BadRequest(new RegisterResponseDTO()
            {
                Errors = new List<string>() { "Invalid payload" },
                Success = false
            });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginUserDTO user)
        {
            if (ModelState.IsValid)
            {
                //var existingUser = await _userService.GetUserByEmail(user.Email);

                //if (existingUser == null)
                //{
                //    return BadRequest(new RegisterResponseDTO()
                //    {
                //        Errors = new List<string>() { "Email address is not registered." },
                //        Success = false
                //    });
                //}
                var existingUser = new UserModel()
                {
                    Email = "canh@lgcns.com",
                    Username = "Canh Nguyen"
                };
                bool isUserCorrect = true; // await _userService.CheckLogin(user);
                if (isUserCorrect)
                {
                    AuthResult authResult = await _jwtService.GenerateToken(existingUser);
                    //return a token
                    return Ok(authResult);
                }
                else
                {
                    return BadRequest(new RegisterResponseDTO()
                    {
                        Errors = new List<string>() { "Wrong password" },
                        Success = false
                    });
                }
            }

            return BadRequest(new RegisterResponseDTO()
            {
                Errors = new List<string>() { "Invalid payload" },
                Success = false
            });
        }

    }
}
