﻿using LG_CHAT_API.Config.Middlewares;
using LG_CHAT_API.Models.BizActor;
using LG_CHAT_API.Models.RoomChat;
using LG_CHAT_API.Services.BizActor;
using Microsoft.AspNetCore.Mvc;

namespace LG_CHAT_API.Controllers
{
    public class RoomChatController : ControllerBaseCustom
    {
        private readonly BizActorServices _services;
        public RoomChatController(BizActorServices services)
        {
            _services = services;
        }

        [HttpPost]
        public async Task<IActionResult> Create(RoomChatModel roomChat, [FromServices] CallerInfo callerInfo)
        {
            roomChat.USER_ID = callerInfo.ID;
            // roomChat.type = "CREATE";

            var refDs = new Dictionary<string, List<object>>();
            refDs.AddInputData("INDT", new List<RoomChatModel>() { roomChat });
            // refDs.AddInputData("INDT12", new List<RoomChatModel>() { roomChat });

            var request = new BizActorRequest()
            {
                ActID = "CRUD_ROOM_CHAT",
                InDTName = "INDT",
                OutDTName = "OUTDT",
                RefDS = refDs
            };

            var result = await _services.Call(request);
            // var roomchatss = _services.GetOutdata<RoomChatModel>(result, "OUTDT");

            return Ok(result);
        }

    }
}
