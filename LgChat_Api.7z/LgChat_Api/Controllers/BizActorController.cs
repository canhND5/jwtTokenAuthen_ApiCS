﻿using LG_CHAT_API.Config.Options;
using LG_CHAT_API.Models.BizActor;
using LG_CHAT_API.Services.BizActor;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LG_CHAT_API.Controllers
{
    public class BizActorController : ControllerBaseCustom
    {
        private readonly IConfiguration _configuration;

        private readonly BizActorServices _services;
        public BizActorController(IConfiguration configuration, BizActorServices services)
        {
            _configuration = configuration;
            _services = services;
        }

        /*
          {"actID" : "SelectCommonCode",
         "inDTName":"InputTb",
         "outDTName":"CommonCodeOut",
         "refDS" :
         {
           "InputTb":[
   		        {"CMCODE":"canhnhe","CMCDTYPE":"CanhAbc"}
 	        ]
         }
        }
        */
        [HttpPost]
        public async Task<IActionResult> CallBizActorService(BizActorRequest request)
        {
            var result = await _services.Call(request);

            // demo cast dictionary to object
            //var dataCommonCode = result.Result["CommonCodeOut"];
            //string listStr = JsonConvert.SerializeObject(dataCommonCode);
            //var data = JsonConvert.DeserializeObject<List<CommonCodeOut>>(listStr);

            return Ok(result);
        }

        // [Authorize(Roles = "Admin")]
        [Authorize]
        [HttpGet]
        public IActionResult GetOption()
        {
            var pos = new PositionOptions();
            _configuration.GetSection(pos.Position).Bind(pos);

            return Ok(pos);
        }
    }
}
