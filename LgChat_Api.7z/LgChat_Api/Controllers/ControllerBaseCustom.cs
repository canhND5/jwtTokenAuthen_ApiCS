﻿using Microsoft.AspNetCore.Mvc;

namespace LG_CHAT_API.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class ControllerBaseCustom : ControllerBase
    {

    }
}
